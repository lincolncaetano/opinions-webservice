package br.com.projeto.controller;

import java.util.List;

import javax.inject.Inject;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;

import br.com.caelum.vraptor.Consumes;
import br.com.caelum.vraptor.Controller;
import br.com.caelum.vraptor.Get;
import br.com.caelum.vraptor.Path;
import br.com.caelum.vraptor.Post;
import br.com.caelum.vraptor.Result;
import br.com.caelum.vraptor.simplemail.Mailer;
import br.com.caelum.vraptor.view.Results;
import br.com.projeto.dao.PostagemDao;
import br.com.projeto.dao.ProdutoDao;
import br.com.projeto.model.Postagem;
import br.com.projeto.model.Produto;
import br.com.projeto.model.Usuario;
import br.com.projeto.utils.AesUtil;

@Controller
public class IndexController {

	private final Result result;
	private Mailer mailer;

	/**
	 * @deprecated CDI eyes only
	 */
	@Deprecated
	protected IndexController() {
		this(null, null);
	}
	
	@Inject
	public IndexController(Result result, Mailer mailer) {
		this.result = result;
		this.mailer = mailer;
	}

	@Path("/")
	public void index() {
		result.include("variable", "Lincoln!");
		List<Produto> listaa = lista();
		result.include("produtoList", listaa);
		
		Produto produto = new Produto();
		produto.setNome("nome 1");
		
		//adicionar(produto);
	}
	
	@Inject
    private ProdutoDao dao;
	
	@Inject
    private PostagemDao postagemDao;
	
	

	@Get
    @Path("/produtos")
	public List<Produto> lista() {
        return dao.listaTodos();
    }
	
	@Get
    @Path("/produtos/{usr.usuario}/{usr.senha}")
	public void senha(Usuario usr) {
		
		
		String senha;
		try {
			
			AesUtil aes = new AesUtil();
			senha = Base64.encodeBase64String(usr.getSenha().getBytes());
			System.out.println(senha);
	
			System.out.println(aes.decrypt("fqMmMwt1632GRQbOLATo7H1Hq2k/4+HPGf6EyjYlX7Q="));
			

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
    }
	
	@Post
	public void enviarEmail() {
		try {
		
			Email email = new SimpleEmail();
			email.setSubject("teste Email");
			email.setFrom("");
			email.addTo("contato@risidevelop.com.br");
			email.setMsg("teste");
			
			mailer.send(email);
		
		
		} catch (EmailException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		result.redirectTo(this).index();
    }
	
	public void load() {
		Produto p = dao.listaTodos().get(0);
		result.use(Results.json()).from(p).serialize();
    }
	
	public void feed() {
		result.use(Results.json()).withoutRoot().from(dao.listaTodos()).serialize();
    }
    
    public void adicionar(Produto produto){
    	dao.adiciona(produto);
    }
    
  

    @Post("/postagemNova")
    @Consumes(value="application/json")
	public void postagemNova(Postagem postagem) {
    		
		postagemDao.adiciona(postagem);
		//result.use(Results.json()).withoutRoot().from(dao.listaTodos()).serialize();
		
    }
    
    @Get
    @Path("/postagem/lista")
	public void listaPostagem() {
		
		result.use(Results.json()).withoutRoot().from(postagemDao.listaTodos()).serialize();
		
    }
    
    
}