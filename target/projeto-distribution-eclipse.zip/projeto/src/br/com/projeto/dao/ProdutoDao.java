package br.com.projeto.dao;

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;

import br.com.projeto.model.Produto;

@RequestScoped
public class ProdutoDao {
	
	@Inject
    private Session session;

	@SuppressWarnings("unchecked")
	public List<Produto> listaTodos() {
        return createCriteria().list();
    }
	
	private Criteria createCriteria() {
        return session.createCriteria(Produto.class);
    }
	
	 public void adiciona(Produto produto) {
		 session.save(produto);
	 }
 
   
}
