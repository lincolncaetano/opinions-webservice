package br.com.projeto.dao;

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;

import br.com.projeto.model.Postagem;

@RequestScoped
public class PostagemDao {
	
	@Inject
    private Session session;

	@SuppressWarnings("unchecked")
	public List<Postagem> listaTodos() {
        return createCriteria().list();
    }
	
	private Criteria createCriteria() {
        return session.createCriteria(Postagem.class).addOrder(Order.desc("id"));
    }
	
	 public void adiciona(Postagem postagem) {
		 session.save(postagem);
	 }

}
